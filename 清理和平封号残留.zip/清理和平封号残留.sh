clear
echo '\n\n\n\n\n'
echo '\033[33m                     正在格机😁\033[0m'
echo '\033[33m                         3\033[0m'
sleep 0.5
echo '\033[33m                         2\033[0m'
sleep 0.5
echo '\033[33m                         1\033[0m'
sleep 0.5
echo '\n\n\n'
echo -e "\033[32m "
echo -e ">>>>>>>>>>>>>>>>>>>>>>>>>> 落泪 >>>>>>>>>>>>>>>>>>>>>>>>>>"
system_path=/private/var/mobile/Containers/Data/Application
app_path=""
for file in $system_path/*; do
    if [ -d "$file/Documents/ShadowTrackerExtra" ];then
		app_path="$file"
	fi
done
echo -e "找到和平精英根目录: $app_path"
delete_path=$app_path/Documents/tss_tmp
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tdm.db
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss_app_915c.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss_cs_stat2.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/api.tpns.sh.tencent.com_IPXL3G6EADY4_xgvipiotprivateserialization.b
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss.i.m.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tersafe.update
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Logs
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Config
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/Caches
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'Saved Application State'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/MidasLog
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/WebKit
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/Cookies
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'Application Support'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/APWsjGameConfInfo.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=/private/var/gg_address
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/sp_default.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'ts.records'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/ts
rm -rf $delete_path
echo "删除 $delete_path 完成"
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   PKG=com.tencent.tmgp.pubgmhd
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /data/data/com.tencent.tmgp.pubgmhd/lib /data/data/com.tencent.tmgp.pubgmhd/.lib
rm -rf /data/data/com.tencent.tmgp.pubgmhd/*
mv /data/data/com.tencent.tmgp.pubgmhd/.lib /data/data/com.tencent.tmgp.pubgmhd/lib
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas/log/com.tencent.tmgp.pubgmhd/
iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/comm.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_ice_bolt.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/databases
chmod 000 //data/data/com.tencent.tmgp.pubgmhd/files/*tmp*
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
chmod 000 /data/media/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/map_movies_1.21.18.11120.pak
system_path=/private/var/mobile/Containers/Data/Application
app_path=""
for file in $system_path/*; do
    if [ -d "$file/Documents/ShadowTrackerExtra" ];then
		app_path="$file"
	fi
done
echo -e "找到和平精英根目录: $app_path"
delete_path=$app_path/Documents/tss_tmp
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tdm.db
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss_app_915c.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss_cs_stat2.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/api.tpns.sh.tencent.com_IPXL3G6EADY4_xgvipiotprivateserialization.b
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss.i.m.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tersafe.update
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Logs
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Config
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/Caches
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'Saved Application State'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/MidasLog
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/WebKit
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/Cookies
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'Application Support'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/APWsjGameConfInfo.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=/private/var/gg_address
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/sp_default.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'ts.records'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/ts
rm -rf $delete_path
echo "删除 $delete_path 完成"
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
echo 0 > /proc/sys/net/nf_conntrack_max
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 0 > /proc/sys/kernel/max_lock_depth
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas/log/com.tencent.tmgp.pubgmhd/
iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/comm.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_ice_bolt.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/databases
chmod 000 //data/data/com.tencent.tmgp.pubgmhd/files/*tmp*
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
system_path=/private/var/mobile/Containers/Data/Application
app_path=""
for file in $system_path/*; do
    if [ -d "$file/Documents/ShadowTrackerExtra" ];then
		app_path="$file"
	fi
done
echo -e "找到和平精英根目录: $app_path"
delete_path=$app_path/Documents/tss_tmp
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tdm.db
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss_app_915c.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss_cs_stat2.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/api.tpns.sh.tencent.com_IPXL3G6EADY4_xgvipiotprivateserialization.b
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss.i.m.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tersafe.update
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Logs
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Config
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/Caches
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'Saved Application State'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/MidasLog
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/WebKit
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/Cookies
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'Application Support'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/APWsjGameConfInfo.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=/private/var/gg_address
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/sp_default.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'ts.records'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/ts
rm -rf $delete_path
echo "删除 $delete_path 完成"
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
echo 0 > /proc/sys/net/nf_conntrack_max
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 0 > /proc/sys/kernel/max_lock_depth
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas/log/com.tencent.tmgp.pubgmhd/
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/comm.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_ice_bolt.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/databases
chmod 000 //data/data/com.tencent.tmgp.pubgmhd/files/*tmp*
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   PKG=com.tencent.tmgp.pubgmhdID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   PKG=com.tencent.tmgp.pubgmhd
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml
echo 0 > /proc/sys/net/nf_conntrack_max
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 0 > /proc/sys/kernel/max_lock_depth
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas/log/com.tencent.tmgp.pubgmhd/
iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/comm.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_ice_bolt.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/databases
chmod 000 //data/data/com.tencent.tmgp.pubgmhd/files/*tmp*
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
system_path=/private/var/mobile/Containers/Data/Application
app_path=""
for file in $system_path/*; do
    if [ -d "$file/Documents/ShadowTrackerExtra" ];then
		app_path="$file"
	fi
done
echo -e "找到和平精英根目录: $app_path"
delete_path=$app_path/Documents/tss_tmp
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tdm.db
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss_app_915c.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss_cs_stat2.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/api.tpns.sh.tencent.com_IPXL3G6EADY4_xgvipiotprivateserialization.b
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss.i.m.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tersafe.update
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Logs
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Config
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/Caches
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'Saved Application State'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/MidasLog
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/WebKit
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/Cookies
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'Application Support'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/APWsjGameConfInfo.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=/private/var/gg_address
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/sp_default.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'ts.records'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/ts
rm -rf $delete_path
echo "删除 $delete_path 完成"
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
echo 0 > /proc/sys/net/nf_conntrack_max
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 0 > /proc/sys/kernel/max_lock_depth
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas/log/com.tencent.tmgp.pubgmhd/
iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/comm.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_ice_bolt.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/databases
chmod 000 //data/data/com.tencent.tmgp.pubgmhd/files/*tmp*
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
echo 0 > /proc/sys/net/nf_conntrack_max
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 0 > /proc/sys/kernel/max_lock_depth
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas/log/com.tencent.tmgp.pubgmhd/
iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/comm.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_ice_bolt.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/databases
chmod 000 //data/data/com.tencent.tmgp.pubgmhd/files/*tmp*
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   PKG=com.tencent.tmgp.pubgmhd
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /sto
system_path=/private/var/mobile/Containers/Data/Application
app_path=""
for file in $system_path/*; do
    if [ -d "$file/Documents/ShadowTrackerExtra" ];then
		app_path="$file"
	fi
done
echo -e "找到和平精英根目录: $app_path"
delete_path=$app_path/Documents/tss_tmp
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tdm.db
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss_app_915c.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss_cs_stat2.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/api.tpns.sh.tencent.com_IPXL3G6EADY4_xgvipiotprivateserialization.b
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss.i.m.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tersafe.update
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Logs
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Config
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/Caches
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'Saved Application State'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/MidasLog
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/WebKit
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/Cookies
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'Application Support'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/APWsjGameConfInfo.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=/private/var/gg_address
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/sp_default.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'ts.records'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/ts
rm -rf $delete_path
echo "删除 $delete_path 完成"
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   PKG=com.tencent.tmgp.pubgmhd
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   PKG=com.tencent.tmgp.pubgmhd
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml
system_path=/private/var/mobile/Containers/Data/Application
app_path=""
for file in $system_path/*; do
    if [ -d "$file/Documents/ShadowTrackerExtra" ];then
		app_path="$file"
	fi
done
echo -e "找到和平精英根目录: $app_path"
delete_path=$app_path/Documents/tss_tmp
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tdm.db
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss_app_915c.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss_cs_stat2.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/api.tpns.sh.tencent.com_IPXL3G6EADY4_xgvipiotprivateserialization.b
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss.i.m.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tersafe.update
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Logs
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Config
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/Caches
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'Saved Application State'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/MidasLog
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/WebKit
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/Cookies
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'Application Support'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/APWsjGameConfInfo.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=/private/var/gg_address
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/sp_default.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'ts.records'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/ts
rm -rf $delete_path
echo "删除 $delete_path 完成"
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
system_path=/private/var/mobile/Containers/Data/Application
app_path=""
for file in $system_path/*; do
    if [ -d "$file/Documents/ShadowTrackerExtra" ];then
		app_path="$file"
	fi
done
echo -e "找到和平精英根目录: $app_path"
delete_path=$app_path/Documents/tss_tmp
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tdm.db
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss_app_915c.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss_cs_stat2.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/api.tpns.sh.tencent.com_IPXL3G6EADY4_xgvipiotprivateserialization.b
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss.i.m.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tersafe.update
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Logs
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Config
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/Caches
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'Saved Application State'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/MidasLog
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/WebKit
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/Cookies
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'Application Support'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/APWsjGameConfInfo.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=/private/var/gg_address
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/sp_default.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'ts.records'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/ts
rm -rf $delete_path
echo "删除 $delete_path 完成"
echo 0 > /proc/sys/net/nf_conntrack_max
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 0 > /proc/sys/kernel/max_lock_depth
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas/log/com.tencent.tmgp.pubgmhd/
iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/comm.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_ice_bolt.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/databases
chmod 000 //data/data/com.tencent.tmgp.pubgmhd/files/*tmp*
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
echo 0 > /proc/sys/net/nf_conntrack_max
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 0 > /proc/sys/kernel/max_lock_depth
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas/log/com.tencent.tmgp.pubgmhd/
iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/comm.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_ice_bolt.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/databases
chmod 000 //data/data/com.tencent.tmgp.pubgmhd/files/*tmp*
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /data/data/com.tencent.tmgp.pubgmhd/lib /data/data/com.tencent.tmgp.pubgmhd/.lib
rm -rf /data/data/com.tencent.tmgp.pubgmhd/*
mv /data/data/com.tencent.tmgp.pubgmhd/.lib /data/data/com.tencent.tmgp.pubgmhd/lib
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /data/data/com.tencent.tmgp.pubgmhd/lib /data/data/com.tencent.tmgp.pubgmhd/.lib
rm -rf /data/data/com.tencent.tmgp.pubgmhd/*
mv /data/data/com.tencent.tmgp.pubgmhd/.lib /data/data/com.tencent.tmgp.pubgmhd/lib
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
echo 0 > /proc/sys/net/nf_conntrack_max
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 0 > /proc/sys/kernel/max_lock_depth
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas/log/com.tencent.tmgp.pubgmhd/
iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/comm.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_ice_bolt.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/databases
chmod 000 //data/data/com.tencent.tmgp.pubgmhd/files/*tmp*
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /data/data/com.tencent.tmgp.pubgmhd/lib /data/data/com.tencent.tmgp.pubgmhd/.lib
rm -rf /data/data/com.tencent.tmgp.pubgmhd/*
mv /data/data/com.tencent.tmgp.pubgmhd/.lib /data/data/com.tencent.tmgp.pubgmhd/lib
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /data/data/com.tencent.tmgp.pubgmhd/lib /data/data/com.tencent.tmgp.pubgmhd/.lib
rm -rf /data/data/com.tencent.tmgp.pubgmhd/*
mv /data/data/com.tencent.tmgp.pubgmhd/.lib /data/data/com.tencent.tmgp.pubgmhd/lib
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /data/data/com.tencent.tmgp.pubgmhd/lib /data/data/com.tencent.tmgp.pubgmhd/.lib
rm -rf /data/data/com.tencent.tmgp.pubgmhd/*
mv /data/data/com.tencent.tmgp.pubgmhd/.lib /data/data/com.tencent.tmgp.pubgmhd/lib
system_path=/private/var/mobile/Containers/Data/Application
app_path=""
for file in $system_path/*; do
    if [ -d "$file/Documents/ShadowTrackerExtra" ];then
		app_path="$file"
	fi
done
echo -e "找到和平精英根目录: $app_path"
delete_path=$app_path/Documents/tss_tmp
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tdm.db
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss_app_915c.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss_cs_stat2.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/api.tpns.sh.tencent.com_IPXL3G6EADY4_xgvipiotprivateserialization.b
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss.i.m.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tersafe.update
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Logs
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Config
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/Caches
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'Saved Application State'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/MidasLog
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/WebKit
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/Cookies
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'Application Support'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/APWsjGameConfInfo.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=/private/var/gg_address
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/sp_default.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'ts.records'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/ts
rm -rf $delete_path
echo "删除 $delete_path 完成"
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas/log/com.tencent.tmgp.pubgmhd/
iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/comm.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_ice_bolt.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/databases
chmod 000 //data/data/com.tencent.tmgp.pubgmhd/files/*tmp*
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas/log/com.tencent.tmgp.pubgmhd/
iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/comm.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_ice_bolt.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/databases
chmod 000 //data/data/com.tencent.tmgp.pubgmhd/files/*tmp*
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /data/data/com.tencent.tmgp.pubgmhd/lib /data/data/com.tencent.tmgp.pubgmhd/.lib
rm -rf /data/data/com.tencent.tmgp.pubgmhd/*
rm -r /data/user/0/com.tencent.tmgp.pubgmhd/files/ano_tmp
mv /data/data/com.tencent.tmgp.pubgmhd/.lib /data/data/com.tencent.tmgp.pubgmhd/lib
iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z
rm -rf /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/*
rm -rf /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/*
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_appcache
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_bugly
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_cn.wsds.sdk.game.data
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_crashSight
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_crashrecord
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_databases
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_dex
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_geolocation
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_midaslib_1
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_midasodex
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_midasplugins
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_msdk
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_pluginlib
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_qmsp
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_tbs
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_tbs_64/
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_tbs_64/core_private
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_tbs_64/core_share
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_textures
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_tga_live_plugin
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_turingdfp
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_turingfd
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_turingsmi
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_webview
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_webview_msdk_inner_webview
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/aware_learning_data
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_webview_slugsdk_ingame_webview
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_webviewxcache
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_webviewxcachedatabases
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_x5webview
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/cache
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/cache/WebView
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/code_cache
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/databases
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/.iii
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/.sys
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/.system_android_l2
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/SpeedUpCCH.dat
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/SpeedUpSHC.dat
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/TDM_KV.log.0
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/TDM_KV.log.10
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/Tencent
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/ace_shell_db.dat
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cef.dat
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/ano_tmp/comm.dat
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_cfg2.dat
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/apm_cc
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/app
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/beacon
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/com.gcloudsdk.gcloud.gvoice
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/com.gcloudsdk.gcloud.gvoice/GVoiceLog/libwxvoiceembed.bin
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/com.tencent.open.config.json.*
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/com.tencent.tmgp.pubgmhd/logging_cache
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/com_tencent_msdk_cacert.*
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/data
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/hawk_data
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/hw_cached_resid.list
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/libwbsafeedit_64.so
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/tbs
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/shared_prefs
rm -rf /data/user_de/0/com.tencent.tmgp.pubgmhd/*
rm -rf /storage/emulated/0/.init
rm -rf /storage/emulated/0/.turing.dat
rm -rf /storage/emulated/0/.zzz
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/.TbsReaderTempcom.tencent.mobileqq
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/.tmp
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/.trooptmp
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/log/*
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.fff
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.system_android_l2
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.vmppd
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/MSDKLog.log.0
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/CONTENT
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/Engine/Saved/Config/Android/Manifest.ini
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ActImageSaved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Demos
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownload
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownloadV3
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/cdn_version.json
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/teg-pcdnvodsdk.txt.xlog
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Cookies/*
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Paks/*
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/*NewActSaveEx.sav
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/3*
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Screenshots
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ShareImageDownload
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TextureConfig
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UGC
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/*
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/down.voice
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/pixuicache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ca-bundle.pem
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent
rm -rf /storage/emulated/0/QTAudioEngine
rm -rf /storage/emulated/0/Tencent/MidasPay
rm -rf /storage/emulated/0/Tencent/MobileQQ
rm -rf /storage/emulated/0/Tencent/ams
rm -rf /storage/emulated/0/Tencent/msflogs
rm -rf /storage/emulated/0/Tencent/tbs
rm -rf /storage/emulated/0/Tencent/tmp
rm -rf /storage/emulated/0/com/tencent
rm -rf /storage/emulated/0/tencent/QQInput/Log/*
rm -rf /storage/emulated/0/tga/
rm -rf /storage/emulated/0/xml.dat
rm -rf /data/data/com.tencent.tmgp.pubgmhd/files/TAPM_CM_AUDIT
chmod -R 000 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
rm -rf /data/data/com.tencent.tmgp.pubgmhd/files/slugsdkconfig.json
rm -rf /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/config3.xml
rm -rf /data/user_de/0/com.tencent.tmgp.pubgmhd
rm -rf /data/data/com.tencent.tmgp.pubgmhd/files/
echo 0 > /proc/sys/net/nf_conntrack_max
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 0 > /proc/sys/kernel/max_lock_depth
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas/log/com.tencent.tmgp.pubgmhd/
iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/comm.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_ice_bolt.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_tcj.dat 
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/databases
chmod 000 //data/data/com.tencent.tmgp.pubgmhd/files/*tmp*
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   PKG=com.tencent.tmgp.pubgmhd
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_appcache
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_bugly
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_cn.wsds.sdk.game.data
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_crashSight
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_crashrecord
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_databases
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_dex
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_geolocation
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_midaslib_1
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_midasodex
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_midasplugins
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_msdk
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_pluginlib
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_qmsp
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_tbs
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_tbs_64/
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_tbs_64/core_private
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_tbs_64/core_share
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_textures
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_tga_live_plugin
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_turingdfp
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_turingfd
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_turingsmi
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_webview
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_webview_msdk_inner_webview
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/aware_learning_data
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_webview_slugsdk_ingame_webview
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_webviewxcache
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_webviewxcachedatabases
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/app_x5webview
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/cache
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/cache/WebView
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/code_cache
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/databases
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/.iii
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/.sys
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/.system_android_l2
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/SpeedUpCCH.dat
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/SpeedUpSHC.dat
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/TDM_KV.log.0
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/TDM_KV.log.10
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/Tencent
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/ace_shell_db.dat
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cef.dat
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/ano_tmp/comm.dat
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_cfg2.dat
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/apm_cc
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/app
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/beacon
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/com.gcloudsdk.gcloud.gvoice
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/com.gcloudsdk.gcloud.gvoice/GVoiceLog/libwxvoiceembed.bin
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/com.tencent.open.config.json.*
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/com.tencent.tmgp.pubgmhd/logging_cache
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/com_tencent_msdk_cacert.*
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/data
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/hawk_data
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/hw_cached_resid.list
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/libwbsafeedit_64.so
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/files/tbs
rm -rf /data/user/0/com.tencent.tmgp.pubgmhd/shared_prefs
rm -rf /data/user_de/0/com.tencent.tmgp.pubgmhd/*
rm -rf /storage/emulated/0/.init
rm -rf /storage/emulated/0/.turing.dat
rm -rf /storage/emulated/0/.zzz
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/.TbsReaderTempcom.tencent.mobileqq
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/.tmp
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/.trooptmp
rm -rf /storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/log/*
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.fff
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.system_android_l2
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.vmppd
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/MSDKLog.log.0
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/CONTENT
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/Engine/Saved/Config/Android/Manifest.ini
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ActImageSaved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Demos
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownload
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownloadV3
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/cdn_version.json
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/teg-pcdnvodsdk.txt.xlog
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Cookies/*
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Paks/*
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/*NewActSaveEx.sav
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/3*
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Screenshots
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ShareImageDownload
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TextureConfig
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UGC
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/*
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/down.voice
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/pixuicache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ca-bundle.pem
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent
rm -rf /storage/emulated/0/QTAudioEngine
rm -rf /storage/emulated/0/Tencent/MidasPay
rm -rf /storage/emulated/0/Tencent/MobileQQ
rm -rf /storage/emulated/0/Tencent/ams
rm -rf /storage/emulated/0/Tencent/msflogs
rm -rf /storage/emulated/0/Tencent/tbs
rm -rf /storage/emulated/0/Tencent/tmp
rm -rf /storage/emulated/0/com/tencent
rm -rf /storage/emulated/0/tencent/QQInput/Log/*
rm -rf /storage/emulated/0/tga/
rm -rf /storage/emulated/0/xml.dat
rm -rf /data/data/com.tencent.tmgp.pubgmhd/files/TAPM_CM_AUDIT
rm -rf /data/data/com.tencent.tmgp.pubgmhd/files/slugsdkconfig.json
rm -rf /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/config3.xml
rm -rf /data/user_de/0/com.tencent.tmgp.pubgmhd
rm -rf /data/data/com.tencent.tmgp.pubgmhd/files/
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   PKG=com.tencent.tmgp.pubgmhd
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas/log/com.tencent.tmgp.pubgmhd/
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
echo 0 > /proc/sys/net/nf_conntrack_max
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 0 > /proc/sys/kernel/max_lock_depth
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas/log/com.tencent.tmgp.pubgmhd/
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 16384 > /proc/sys/fs/inotify/max_queued_events
system_path=/private/var/mobile/Containers/Data/Application
app_path=""
for file in $system_path/*; do
    if [ -d "$file/Documents/ShadowTrackerExtra" ];then
		app_path="$file"
	fi
done
echo -e "找到和平精英根目录: $app_path"
delete_path=$app_path/Documents/tss_tmp
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tdm.db
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss_app_915c.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss_cs_stat2.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/api.tpns.sh.tencent.com_IPXL3G6EADY4_xgvipiotprivateserialization.b
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tss.i.m.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/tersafe.update
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Logs
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Config
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/Caches
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'Saved Application State'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/MidasLog
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/WebKit
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/Cookies
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'Application Support'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/APWsjGameConfInfo.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=/private/var/gg_address
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Documents/sp_default.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/'ts.records'
rm -rf $delete_path
echo "删除 $delete_path 完成"
delete_path=$app_path/Library/ts
rm -rf $delete_path
echo "删除 $delete_path 完成"
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas/log/com.tencent.tmgp.pubgmhd/
iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/comm.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_ice_bolt.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/databases
chmod 000 //data/data/com.tencent.tmgp.pubgmhd/files/*tmp*
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas/log/com.tencent.tmgp.pubgmhd/
iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/comm.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_ice_bolt.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/databases
chmod 000 //data/data/com.tencent.tmgp.pubgmhd/files/*tmp*
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /data/data/com.tencent.tmgp.pubgmhd/lib /data/data/com.tencent.tmgp.pubgmhd/.lib
rm -rf /data/data/com.tencent.tmgp.pubgmhd/*
rm -r /data/user/0/com.tencent.tmgp.pubgmhd/files/ano_tmp
mv /data/data/com.tencent.tmgp.pubgmhd/.lib /data/data/com.tencent.tmgp.pubgmhd/lib
iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z
rm -rf /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/*
rm -rf /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/*
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
echo 0 > /proc/sys/net/nf_conntrack_max
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 0 > /proc/sys/kernel/max_lock_depth
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/midas/log/com.tencent.tmgp.pubgmhd/
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/comm.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/databases
chmod 000 //data/data/com.tencent.tmgp.pubgmhd/files/*tmp*
chmod 000 /data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp
PKG=com.tencent.tmgp.pubgmhd
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd
am force-stop com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/*
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/.files /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1
pm clear com.tencent.tmgp.pubgmhd
mv /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd1 /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd










"\033[0m"
clear
echo -e "\033[32m "'\n\n\n\n\n\n\n\n\n\n      ‿︵‿︵‿︵୨˚̣̣̣͙୧- \033[33m每日一言\033[0m \033[32m-୨˚̣̣̣͙୧‿︵‿︵‿︵\n\n'" $(curl -s --insecure -H "Cache-Control: no-cache" "https://v1.hitokoto.cn/?encode=text&charset=utf-8") "'\n\n'"\033[0m"
echo '\033[33m\n\n\n\n\n              落泪 @yirlll\n              改id重启即可\n              登陆动画已过\033[0m'
echo -e "\033[32m$(date +"%Y年%m月%d日%H时%M分%S秒")\033[0m"


